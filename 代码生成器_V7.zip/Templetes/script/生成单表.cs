        using System.Text;
		using System.IO;
		
		/// <summary>
        /// 生成代码
        /// </summary>
        /// <param name="dbType">数据库类型</param>
		/// <param name="namespaceStr">命名空间</param>
		/// <param name="classBefore">类名前缀</param>
		/// <param name="classAfter">类名后缀</param>		
        /// <param name="connectionUrl">连接字符串</param>
        /// <param name="tableName">表名</param>
        /// <param name="columns">字段(string[]的长度为2，第一个为字段名称，第二个为字段类型)</param>
        /// <returns>生成后的代码</returns>
        string make(string dbType,string namespaceStr,string classBefore,string classAfter,string connectionUrl, string tableName, System.Collections.Generic.List<string[]> columns)
        {
			StringBuilder sb = new StringBuilder();
			sb.Append("using System;\n");
			sb.Append("using System.Data;\n");
			sb.Append("using System.Text;\n");
			sb.Append("\n");
			sb.Append("namespace ").Append(namespaceStr).Append(" \n");
			sb.Append("{\n");
			sb.Append("    /// <summary>\n");
			sb.Append("    /// 类").Append(tableName).Append("。\n");
			sb.Append("    /// </summary>\n");
			sb.Append("    [Serializable]\n");
			sb.Append("    public partial class ").Append(classBefore).Append(tableName).Append(classAfter).Append(" : IEntity\n");
			sb.Append("    {\n");
			sb.Append("        public ").Append(classBefore).Append(tableName).Append(classAfter).Append("() { }\n");
			sb.Append("\n");
			sb.Append("        public override Noear.Weed.DbTableQuery copyTo(Noear.Weed.DbTableQuery query)\n");
			sb.Append("        {\n");
			sb.Append("            //设置值\n");
			foreach(string[] cols in columns){
			   sb.Append("            query.set(\"").Append(cols[0]).Append("\", ").Append(cols[0]).Append(");\n");
			}
			
			sb.Append("\n");
			sb.Append("            return query;\n");
			sb.Append("        }\n");
			sb.Append("\n");
			
			foreach(string[] cols in columns){
			   sb.Append("        public ").Append(cols[1].ToLower()).Append(" ").Append(cols[0]).Append(" { get; set; }\n");
			}
			
			sb.Append("\n");
			sb.Append("        public override void bind(Noear.Weed.GetHandlerEx source)\n");
			sb.Append("        {\n");
			
			foreach(string[] cols in columns){
			   sb.Append("            ").Append(cols[0]).Append(" = source(\"").Append(cols[0]).Append("\").value<").Append(cols[1].ToLower()).Append(">(\"\");\n");
			}
			
			sb.Append("        }\n");
			sb.Append("\n");
			sb.Append("        public override Noear.Weed.IBinder clone()\n");
			sb.Append("        {\n");
			sb.Append("            return new ").Append(tableName).Append("();\n");
			sb.Append("        }\n");
			sb.Append("    }\n");
			sb.Append("}\n");
            return sb.ToString();
        }